import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CinemasList extends StatefulWidget {
  _CinemasList createState() => _CinemasList();
}

class _CinemasList extends State<CinemasList> {
  @override
  Widget build(BuildContext context) {

    SystemChrome.setPreferredOrientations([
  DeviceOrientation.landscapeLeft,
  DeviceOrientation.landscapeRight,
]);
    return Scaffold(
      appBar: AppBar(
        title: Text("List"),
      ),
      body: OrientationBuilder(
        builder:(context, orientation) {
          return GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 15,
            mainAxisSpacing: 10.0,
            crossAxisSpacing: 10.0,
          ),
          itemCount: 210,
          itemBuilder: (BuildContext context , int index){
            return Container(color: Colors.green,);
          },
        );
         } 
        //  child: child,
      ),
    );
  }
}
