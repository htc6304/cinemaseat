import 'package:flutter/material.dart';

class SettingWidget extends StatelessWidget{
// @override
Widget build(BuildContext context){
  return Text("this is Setting page");
}

}